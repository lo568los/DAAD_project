//go:build windows
// +build windows

package config

var netrcBasename = "_netrc"
