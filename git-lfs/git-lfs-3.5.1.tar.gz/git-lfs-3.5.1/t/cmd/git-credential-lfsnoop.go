//go:build testtools
// +build testtools

package main

func main() {
}
